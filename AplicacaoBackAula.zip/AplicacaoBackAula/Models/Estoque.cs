﻿using System;
using System.Collections.Generic;

namespace AplicacaoBackAula.Models;

public partial class Estoque
{
    public int Idestoque { get; set; }

    public int Iditem { get; set; }

    public int QuantidadeEstoque { get; set; }
}
