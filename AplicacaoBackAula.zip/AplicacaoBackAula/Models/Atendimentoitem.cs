﻿using System;
using System.Collections.Generic;

namespace AplicacaoBackAula.Models;

public partial class Atendimentoitem
{
    public int Idatendimentoitem { get; set; }

    public int AtendimentoIdatendimento { get; set; }

    public int ItemIditem { get; set; }

    public int Idfuncionario { get; set; }

    public int QuantidadeItens { get; set; }

    public decimal ValorunitarioEntrada { get; set; }

    public virtual Atendimento AtendimentoIdatendimentoNavigation { get; set; } = null!;

    public virtual Item ItemIditemNavigation { get; set; } = null!;
}
