﻿namespace AplicacaoBackAula.DTO
{
    public class FuncionarioEntradaDTO
    {
        //pessoa
        public string? Nome { get; set; }
        public long CPF { get; set; }
        public DateOnly DataNascimento { get; set; }
        public string? Sexo { get; set; }
        public string? Email { get; set; }
        public long Telefone { get; set; }
        public string? AtivoPessoa { get; set; }

        //funcionário
        public string? Cargo { get; set; }
        public DateOnly DataAdmissao { get; set; }

        //endereço
        public List<EnderecoDTO> Enderecos { get; set; } = new();
    }
}
