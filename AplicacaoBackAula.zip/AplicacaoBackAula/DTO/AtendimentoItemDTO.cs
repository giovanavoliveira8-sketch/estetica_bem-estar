namespace AplicacaoBackAula.DTO
{
    public class AtendimentoItemDTO
    {
        public int Idatendimentoitem { get; set; }

        public int AtendimentoIdatendimento { get; set; }
  
        public int ItemIditem { get; set; }

        public int Idfuncionario { get; set; }

        public int QuantidadeItens { get; set; }

        public decimal ValorunitarioEntrada { get; set; }
    }
}
