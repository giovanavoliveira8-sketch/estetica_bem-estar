﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AplicacaoBackAula.DTO;
using AplicacaoBackAula.Models;

namespace AplicacaoBackAula.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AtendimentoController : ControllerBase
    {
        private readonly BdAulaBackendContext _context;

        public AtendimentoController(BdAulaBackendContext context)
        {
            _context = context;
        }

        // GET (consultar/buscar): listar todos os atendimentos
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AtendimentoDTO>>> GetAtendimentos()
        {
            var atendimentos = await _context.Atendimentos
                .Select(a => new AtendimentoDTO
                {
                    Idatendimento = a.Idatendimento,
                    Idpessoa = a.Idpessoa,
                    DataAtendimento = a.DataAtendimento,
                    StatusAtendimento = a.StatusAtendimento
                })
                .ToListAsync();

            return Ok(atendimentos);
        }

        // GET: consultar um atendimento pelo ID
        [HttpGet("{id}")]
        public async Task<ActionResult<AtendimentoDTO>> GetAtendimento(int id)
        {
            var atendimento = await _context.Atendimentos
                .Where(a => a.Idatendimento == id)
                .Select(a => new AtendimentoDTO
                {
                    Idatendimento = a.Idatendimento,
                    Idpessoa = a.Idpessoa,
                    DataAtendimento = a.DataAtendimento,
                    StatusAtendimento = a.StatusAtendimento
                })
                .FirstOrDefaultAsync();

            if (atendimento == null)
                return NotFound("Atendimento não encontrado.");

            return Ok(atendimento);
        }

        // POST: cadastrar um atendimento
        [HttpPost]
        public async Task<ActionResult<AtendimentoDTO>> PostAtendimento(
            AtendimentoDTO dto)
        {
            if (string.IsNullOrWhiteSpace(dto.StatusAtendimento))
                return BadRequest("Informe o status do atendimento.");

            var pessoa = await _context.Pessoas
                .AnyAsync(p => p.Idpessoa == dto.Idpessoa);

            if (!pessoa)
                return BadRequest("A pessoa informada não existe.");

            var atendimento = new Atendimento
            {
                Idpessoa = dto.Idpessoa,
                DataAtendimento = dto.DataAtendimento,
                StatusAtendimento = dto.StatusAtendimento
            };

            _context.Atendimentos.Add(atendimento);
            await _context.SaveChangesAsync();

            dto.Idatendimento = atendimento.Idatendimento;

            return CreatedAtAction(
                nameof(GetAtendimento),
                new { id = atendimento.Idatendimento },
                dto);
        }

        // PUT: atualizar um atendimento
        [HttpPut("{id}")]
        public async Task<IActionResult> PutAtendimento(
            int id, AtendimentoDTO dto)
        {
            var atendimento = await _context.Atendimentos
                .FirstOrDefaultAsync(a => a.Idatendimento == id);

            if (atendimento == null)
                return NotFound("Atendimento não encontrado.");

            var pessoa = await _context.Pessoas
                .AnyAsync(p => p.Idpessoa == dto.Idpessoa);

            if (!pessoa)
                return BadRequest("A pessoa informada não existe.");

            if (string.IsNullOrWhiteSpace(dto.StatusAtendimento))
                return BadRequest("Informe o status do atendimento.");

            atendimento.Idpessoa = dto.Idpessoa;
            atendimento.DataAtendimento = dto.DataAtendimento;
            atendimento.StatusAtendimento = dto.StatusAtendimento;

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: excluir um atendimento
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteAtendimento(int id)
        {
            var atendimento = await _context.Atendimentos
                .Include(a => a.Atendimentoitems)
                .FirstOrDefaultAsync(a => a.Idatendimento == id);

            if (atendimento == null)
                return NotFound("Atendimento não encontrado.");

            if (atendimento.Atendimentoitems.Any())
            {
                return Conflict(
                    "Não é possível excluir o atendimento enquanto houver itens associados. Remova os itens primeiro.");
            }

            _context.Atendimentos.Remove(atendimento);
            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
