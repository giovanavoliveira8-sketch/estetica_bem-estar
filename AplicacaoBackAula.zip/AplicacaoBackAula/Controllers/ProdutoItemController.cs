﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AplicacaoBackAula.Models;
using AplicacaoBackAula.DTO;

namespace AplicacaoBackAula.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProdutoItemController : ControllerBase
    {
        private readonly BdAulaBackendContext _context;

        public ProdutoItemController(BdAulaBackendContext context)
        {
            _context = context;
        }

        // LISTAR TODOS OS PRODUTOS
        [HttpGet]
        public async Task<IActionResult> GetProdutos()
        {
            var produtos = await _context.Produtos
                .Select(p => new
                {
                    p.Idproduto,
                    p.Iditem,
                    p.CodigoPreco,
                    p.PrecoVenda,
                    p.Unidade,

                    IditemNavigation = new
                    {
                        p.IditemNavigation.Iditem,
                        p.IditemNavigation.Idcategoria,
                        p.IditemNavigation.Item1,
                        p.IditemNavigation.DescricaoItem,
                        p.IditemNavigation.Preco,
                        p.IditemNavigation.TipoItem,
                        p.IditemNavigation.AtivoProdutoServico,

                        IdcategoriaNavigation = new
                        {
                            p.IditemNavigation.IdcategoriaNavigation.Idcategoria,
                            p.IditemNavigation.IdcategoriaNavigation.Categoria
                        }
                    }
                })
                .ToListAsync();

            return Ok(produtos);
        }

        // CONSULTAR PRODUTO PELO ID
        [HttpGet("id")]
        public async Task<IActionResult> GetProdutoPorId(int id)
        {
            var produto = await _context.Produtos
                .Where(p => p.Iditem == id)
                .Select(p => new
                {
                    p.Idproduto,
                    p.Iditem,
                    p.CodigoPreco,
                    p.PrecoVenda,
                    p.Unidade,

                    IditemNavigation = new
                    {
                        p.IditemNavigation.Iditem,
                        p.IditemNavigation.Idcategoria,
                        p.IditemNavigation.Item1,
                        p.IditemNavigation.DescricaoItem,
                        p.IditemNavigation.Preco,
                        p.IditemNavigation.TipoItem,
                        p.IditemNavigation.AtivoProdutoServico,

                        IdcategoriaNavigation = new
                        {
                            p.IditemNavigation.IdcategoriaNavigation.Idcategoria,
                            p.IditemNavigation.IdcategoriaNavigation.Categoria
                        }
                    }
                })
                .FirstOrDefaultAsync();

            if (produto == null)
            {
                return NotFound(new
                {
                    mensagem = "Produto Não Localizado"
                });
            }

            return Ok(produto);
        }

        // CADASTRAR PRODUTO
        [HttpPost]
        public async Task<ActionResult> PostProduto(ProdutoDTO dados)
        {
            using var transaction =
                await _context.Database.BeginTransactionAsync();

            try
            {
                var item = new Item
                {
                    Idcategoria = dados.Idcategoria,
                    Item1 = dados.Item,
                    DescricaoItem = dados.DescricaoItem,
                    Preco = dados.Preco,
                    TipoItem = dados.TipoItem,
                    AtivoProdutoServico = dados.AtivoProdutoServico
                };

                _context.Items.Add(item);
                await _context.SaveChangesAsync();

                int IdItemGerado = item.Iditem;

                var produto = new Produto
                {
                    Iditem = IdItemGerado,
                    CodigoPreco = dados.CodigoPreco,
                    PrecoVenda = dados.PrecoVenda,
                    Unidade = dados.Unidade
                };

                _context.Produtos.Add(produto);
                await _context.SaveChangesAsync();

                await transaction.CommitAsync();

                return CreatedAtAction(
                    nameof(GetProdutoPorId),
                    new { id = produto.Iditem },
                    produto
                );
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();

                return StatusCode(500, new
                {
                    mensagem = "Erro ao cadastrar produto.",
                    erro = ex.Message
                });
            }
        }

        // EDITAR PRODUTO
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduto(int id, ProdutoDTO dados)
        {
            var produtoExistente = await _context.Produtos
                .Include(p => p.IditemNavigation)
                .FirstOrDefaultAsync(p => p.Iditem == id);

            if (produtoExistente == null)
            {
                return NotFound(new
                {
                    mensagem = "Produto não encontrado."
                });
            }

            produtoExistente.CodigoPreco = dados.CodigoPreco;
            produtoExistente.PrecoVenda = dados.PrecoVenda;
            produtoExistente.Unidade = dados.Unidade;

            produtoExistente.IditemNavigation.Idcategoria = dados.Idcategoria;
            produtoExistente.IditemNavigation.Item1 = dados.Item;
            produtoExistente.IditemNavigation.DescricaoItem = dados.DescricaoItem;
            produtoExistente.IditemNavigation.Preco = dados.Preco;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ProdutoExists(id))
                {
                    return NotFound(new
                    {
                        mensagem = "Produto não encontrado."
                    });
                }

                throw;
            }

            return NoContent();
        }

        // EXCLUIR PRODUTO
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduto(int id)
        {
            using var transaction =
                await _context.Database.BeginTransactionAsync();

            try
            {
                var produto = await _context.Produtos
                    .FirstOrDefaultAsync(p => p.Iditem == id);

                if (produto == null)
                {
                    return NotFound(new
                    {
                        mensagem = "Produto não encontrado."
                    });
                }

                _context.Produtos.Remove(produto);
                await _context.SaveChangesAsync();

                var item = await _context.Items
                    .FirstOrDefaultAsync(i => i.Iditem == id);

                if (item != null)
                {
                    _context.Items.Remove(item);
                    await _context.SaveChangesAsync();
                }

                await transaction.CommitAsync();
                return NoContent();
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();

                return StatusCode(500, new
                {
                    mensagem = "Erro ao excluir produto.",
                    erro = ex.Message
                });
            }
        }

        private bool ProdutoExists(int id)
        {
            return _context.Produtos.Any(e => e.Iditem == id);
        }
    }
}
