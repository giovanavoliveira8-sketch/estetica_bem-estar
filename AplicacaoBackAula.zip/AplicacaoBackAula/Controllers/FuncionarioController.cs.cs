﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AplicacaoBackAula.DTO;
using AplicacaoBackAula.Models;

namespace AplicacaoBackAula.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FuncionarioController : ControllerBase
    {
        private readonly BdAulaBackendContext _context;

        public FuncionarioController(BdAulaBackendContext context)
        {
            _context = context;
        }

        // GET: listar funcionários
        [HttpGet]
        public async Task<ActionResult<IEnumerable<FuncionarioSaidaDTO>>> GetFuncionarios()
        {

            var funcionarios = await _context.Funcionarios
                .OrderBy(f => f.Idfuncionario)
                .Select(f => new FuncionarioSaidaDTO

                {
                    IdPessoa = f.Idpessoa,
                    Nome = f.IdpessoaNavigation.Nome,
                    CPF = f.IdpessoaNavigation.Cpf,
                    DataNascimento = f.IdpessoaNavigation.DataNascimento,
                    Sexo = f.IdpessoaNavigation.Sexo,
                    Email = f.IdpessoaNavigation.Email,
                    Telefone = f.IdpessoaNavigation.Telefone,
                    AtivoPessoa = f.IdpessoaNavigation.AtivoPessoa,

                    Idfuncionario = f.Idfuncionario,
                    Cargo = f.Cargo,
                    DataAdmissao = f.DataAdmissao,

                    Enderecos = f.IdpessoaNavigation.Enderecos
                        .Select(e => new EnderecoDTO
                        {
                            IdPessoa = e.Idpessoa,
                            CEP = e.Cep,
                            Numero = e.Numero,
                            Complemento = e.Complemento
                        }).ToList()
                })
                .ToListAsync();

            return Ok(funcionarios);
        }

        // GET: consultar funcionário pelo ID da pessoa
        [HttpGet("{id}")]
        public async Task<ActionResult<FuncionarioSaidaDTO>> GetFuncionario(int id)
        {
            var funcionario = await _context.Funcionarios
                .Where(f => f.Idpessoa == id)
                .Select(f => new FuncionarioSaidaDTO
                {
                    IdPessoa = f.Idpessoa,
                    Nome = f.IdpessoaNavigation.Nome,
                    CPF = f.IdpessoaNavigation.Cpf,
                    DataNascimento = f.IdpessoaNavigation.DataNascimento,
                    Sexo = f.IdpessoaNavigation.Sexo,
                    Email = f.IdpessoaNavigation.Email,
                    Telefone = f.IdpessoaNavigation.Telefone,
                    AtivoPessoa = f.IdpessoaNavigation.AtivoPessoa,

                    Idfuncionario = f.Idfuncionario,
                    Cargo = f.Cargo,
                    DataAdmissao = f.DataAdmissao,

                    Enderecos = f.IdpessoaNavigation.Enderecos
                        .Select(e => new EnderecoDTO
                        {
                            IdPessoa = e.Idpessoa,
                            CEP = e.Cep,
                            Numero = e.Numero,
                            Complemento = e.Complemento
                        }).ToList()
                })
                .FirstOrDefaultAsync();

            if (funcionario == null)
            {
                return NotFound();
            }

            return Ok(funcionario);
        }

        // POST: cadastrar pessoa, endereços e funcionário
        [HttpPost("id")]
        public async Task<ActionResult<FuncionarioSaidaDTO>> PostFuncionario(
            FuncionarioEntradaDTO dto)
        {
            var pessoa = new Pessoa
            {
                Nome = dto.Nome,
                Cpf = dto.CPF,
                DataNascimento = dto.DataNascimento,
                Sexo = dto.Sexo,
                Email = dto.Email,
                Telefone = dto.Telefone,
                AtivoPessoa = dto.AtivoPessoa,

                Enderecos = dto.Enderecos.Select(e => new Endereco
                {
                    Cep = e.CEP,
                    Numero = e.Numero,
                    Complemento = e.Complemento
                }).ToList()
            };

            _context.Pessoas.Add(pessoa);

            await _context.SaveChangesAsync();

            var funcionario = new Funcionario
            {
                Idpessoa = pessoa.Idpessoa,
                DataAdmissao = dto.DataAdmissao
            };

            if (dto.Cargo != null)
            {
                funcionario.Cargo = dto.Cargo;
            }
            else
            {
                funcionario.Cargo = "";
            }

            _context.Funcionarios.Add(funcionario);

            await _context.SaveChangesAsync();

            var resposta = new FuncionarioSaidaDTO
            {
                IdPessoa = pessoa.Idpessoa,
                Nome = pessoa.Nome,
                CPF = pessoa.Cpf,
                DataNascimento = pessoa.DataNascimento,
                Sexo = pessoa.Sexo,
                Email = pessoa.Email,
                Telefone = pessoa.Telefone,
                AtivoPessoa = pessoa.AtivoPessoa,

                Idfuncionario = funcionario.Idfuncionario,
                Cargo = funcionario.Cargo,
                DataAdmissao = funcionario.DataAdmissao,

                Enderecos = pessoa.Enderecos.Select(e => new EnderecoDTO
                {
                    IdPessoa = e.Idpessoa,
                    CEP = e.Cep,
                    Numero = e.Numero,
                    Complemento = e.Complemento
                }).ToList()
            };

            return CreatedAtAction(
                nameof(GetFuncionario),
                new { id = pessoa.Idpessoa },
                resposta);
        }

        // PUT: atualizar funcionário
        [HttpPut("{id}")]
        public async Task<IActionResult> PutFuncionario(
            int id, FuncionarioEntradaDTO dto)
        {
            var funcionario = await _context.Funcionarios
                .Include(f => f.IdpessoaNavigation)
                .ThenInclude(p => p.Enderecos)
                .FirstOrDefaultAsync(f => f.Idpessoa == id);

            if (funcionario == null)
            {
                return NotFound();
            }

            var pessoa = funcionario.IdpessoaNavigation;

            pessoa.Nome = dto.Nome;
            pessoa.Cpf = dto.CPF;
            pessoa.DataNascimento = dto.DataNascimento;
            pessoa.Sexo = dto.Sexo;
            pessoa.Email = dto.Email;
            pessoa.Telefone = dto.Telefone;
            pessoa.AtivoPessoa = dto.AtivoPessoa;

            funcionario.DataAdmissao = dto.DataAdmissao;

            if (dto.Cargo != null)
            {
                funcionario.Cargo = dto.Cargo;
            }
            else
            {
                funcionario.Cargo = "";
            }

            _context.Enderecos.RemoveRange(pessoa.Enderecos);

            foreach (var enderecoDTO in dto.Enderecos)
            {
                var endereco = new Endereco
                {
                    Idpessoa = pessoa.Idpessoa,
                    Cep = enderecoDTO.CEP,
                    Numero = enderecoDTO.Numero,
                    Complemento = enderecoDTO.Complemento
                };

                pessoa.Enderecos.Add(endereco);
            }

            await _context.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: excluir funcionário
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteFuncionario(int id)
        {
            var funcionario = await _context.Funcionarios
                .FirstOrDefaultAsync(f => f.Idpessoa == id);

            if (funcionario == null)
            {
                return NotFound();
            }

            _context.Funcionarios.Remove(funcionario);

            await _context.SaveChangesAsync();

            return NoContent();
        }
    }
}
