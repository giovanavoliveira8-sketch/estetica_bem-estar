﻿
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AplicacaoBackAula.DTO;
using AplicacaoBackAula.Models;

namespace AplicacaoBackAula.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EntradaProdutoController : ControllerBase
    {
        private readonly BdAulaBackendContext _context;

        public EntradaProdutoController(BdAulaBackendContext context)
        {
            _context = context;
        }

        // GET: listar todas as entradas
        [HttpGet]
        public async Task<ActionResult<IEnumerable<EntradaProdutoDTO>>> GetEntradas()
        {
            var entradas = await _context.EntradaProdutos
                .Select(e => new EntradaProdutoDTO
                {
                    IdentradaProduto = e.IdentradaProduto,
                    Iditem = e.Iditem,
                    DataEntradaProduto = e.DataEntradaProduto,
                    QuantidadeEntrada = e.QuantidadeEntrada,
                    Unidade = e.Unidade,
                    ValorUnitarioEntrada = e.ValorUnitarioEntrada
                })
                .ToListAsync();

            return Ok(entradas);
        }

        // GET: buscar uma entrada pelos identificadores
        [HttpGet("{id}/{iditem}")]
        public async Task<ActionResult<EntradaProdutoDTO>> GetEntrada(
            int id, int iditem)
        {
            var entrada = await _context.EntradaProdutos
                .Where(e => e.IdentradaProduto == id &&
                            e.Iditem == iditem)
                .Select(e => new EntradaProdutoDTO
                {
                    IdentradaProduto = e.IdentradaProduto,
                    Iditem = e.Iditem,
                    DataEntradaProduto = e.DataEntradaProduto,
                    QuantidadeEntrada = e.QuantidadeEntrada,
                    Unidade = e.Unidade,
                    ValorUnitarioEntrada = e.ValorUnitarioEntrada
                })
                .FirstOrDefaultAsync();

            if (entrada == null)
                return NotFound();

            return Ok(entrada);
        }

        // POST: cadastrar uma entrada e atualizar o estoque
        [HttpPost]
        public async Task<ActionResult<EntradaProdutoDTO>> PostEntrada(
            EntradaProdutoDTO dto)
        {
            if (dto.QuantidadeEntrada <= 0 ||
                dto.QuantidadeEntrada != Math.Truncate(dto.QuantidadeEntrada))
            {
                return BadRequest(
                    "A quantidade deve ser positiva e inteira, pois o estoque utiliza números inteiros.");
            }

            var estoque = await _context.Estoques
                .FirstOrDefaultAsync(e => e.Iditem == dto.Iditem);

            if (estoque == null)
                return NotFound("Estoque não encontrado para esse item.");

            await using var transacao =
                await _context.Database.BeginTransactionAsync();

            estoque.QuantidadeEstoque += (int)dto.QuantidadeEntrada;

            var entrada = new EntradaProduto
            {
                IdentradaProduto = dto.IdentradaProduto,
                Iditem = dto.Iditem,
                DataEntradaProduto = dto.DataEntradaProduto,
                QuantidadeEntrada = dto.QuantidadeEntrada,
                Unidade = dto.Unidade,
                ValorUnitarioEntrada = dto.ValorUnitarioEntrada
            };

            _context.EntradaProdutos.Add(entrada);

            await _context.SaveChangesAsync();
            await transacao.CommitAsync();

            return CreatedAtAction(
                nameof(GetEntrada),
                new
                {
                    id = entrada.IdentradaProduto,
                    iditem = entrada.Iditem
                },
                dto);
        }

        // PUT: atualizar uma entrada e ajustar o estoque
        [HttpPut("{id}/{iditem}")]
        public async Task<IActionResult> PutEntrada(
            int id, int iditem, EntradaProdutoDTO dto)
        {
            if (dto.QuantidadeEntrada <= 0 ||
                dto.QuantidadeEntrada != Math.Truncate(dto.QuantidadeEntrada))
            {
                return BadRequest(
                    "A quantidade deve ser positiva e inteira.");
            }

            if (dto.Iditem != iditem)
                return BadRequest("O iditem não pode ser alterado.");

            var entrada = await _context.EntradaProdutos
                .FirstOrDefaultAsync(e =>
                    e.IdentradaProduto == id &&
                    e.Iditem == iditem);

            if (entrada == null)
                return NotFound("Entrada não encontrada.");

            var estoque = await _context.Estoques
                .FirstOrDefaultAsync(e => e.Iditem == iditem);

            if (estoque == null)
                return NotFound("Estoque não encontrado.");

            int diferenca =
                (int)dto.QuantidadeEntrada -
                (int)entrada.QuantidadeEntrada;

            if (estoque.QuantidadeEstoque + diferenca < 0)
                return BadRequest("O estoque não pode ficar negativo.");

            await using var transacao =
                await _context.Database.BeginTransactionAsync();

            estoque.QuantidadeEstoque += diferenca;

            entrada.DataEntradaProduto = dto.DataEntradaProduto;
            entrada.QuantidadeEntrada = dto.QuantidadeEntrada;
            entrada.Unidade = dto.Unidade;
            entrada.ValorUnitarioEntrada = dto.ValorUnitarioEntrada;

            await _context.SaveChangesAsync();
            await transacao.CommitAsync();

            return NoContent();
        }

        // DELETE: excluir uma entrada e descontar do estoque
        [HttpDelete("{id}/{iditem}")]
        public async Task<IActionResult> DeleteEntrada(
            int id, int iditem)
        {
            var entrada = await _context.EntradaProdutos
                .FirstOrDefaultAsync(e =>
                    e.IdentradaProduto == id &&
                    e.Iditem == iditem);

            if (entrada == null)
                return NotFound("Entrada não encontrada.");

            var estoque = await _context.Estoques
                .FirstOrDefaultAsync(e => e.Iditem == iditem);

            if (estoque == null)
                return NotFound("Estoque não encontrado.");

            if (estoque.QuantidadeEstoque <
                entrada.QuantidadeEntrada)
            {
                return BadRequest(
                    "Não é possível excluir a entrada porque a quantidade no estoque é insuficiente.");
            }

            await using var transacao =
                await _context.Database.BeginTransactionAsync();

            estoque.QuantidadeEstoque -=
                (int)entrada.QuantidadeEntrada;

            _context.EntradaProdutos.Remove(entrada);

            await _context.SaveChangesAsync();
            await transacao.CommitAsync();

            return NoContent();
        }
    }
}
